import "../../Assets/Cards/Cards.scss";

// import img from "../../Assets/Images/las vegas.jpg";

// import CardsStyles from "../../Assets/Cards/Cards.module.scss";

// import Cards from "./Cards";
const Cards = ({ Img, Title, children }) => {
  return (
    <div>
      <div className="container">
        <div className="Card_Wrapper">
          <article className="Card_Poster">
            <img src={Img} alt="" />
          </article>
          <article className="Card_Context">
            <h3>{Title}</h3>
            <p>{children}</p>
            <button>Click me</button>
          </article>
        </div>
      </div>
    </div>
  );
};
export default Cards;
