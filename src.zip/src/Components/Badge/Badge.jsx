import "../../Assets/Badge/Badge.scss";
import Bell from "../../Assets/Images/Bell/w-1.png";

const Notification = () => {
  let randomNot = Math.floor(Math.random() * 100);
  return randomNot;
};

const Badge = () => {
  return (
    <div className="bellContainer">
      <img src={Bell} alt="bell" className="bell" />
      <span>{Notification()}</span>
    </div>
  );
};
export default Badge;
