import "../../Assets/Sign/Sign.scss";

const SignIn = () => {
  return <button className="btn draw-border">Sign In</button>;
};
export default SignIn;
