import "../../Assets/Navbar/Navbar.scss";
import Badge from "../Badge/Badge";
import SignIn from "../Sign/Sign";

const Navbar = () => {
  return (
    <div className="Navbar-Wrapper">
      <section>
        <Badge />
      </section>
      <section style={{ position: "relative", bottom: "30px", color: "azure" }}>
        <ul>
          <li className="firstLiChild">Home</li>
          <li>About</li>
          <li>Careers</li>
          <li>Contact</li>
        </ul>
      </section>
      <SignIn />
    </div>
  );
};
export default Navbar;
