import "./App.scss";
import Cards from "./Components/Card/Cards";
import Navbar from "./Components/Navbar/Navbar";
import NewyorkImg from "./Assets/Images/newyork.jpg";
import React, { Component } from "react";
import SingaporeImg from "./Assets/Images/singapore.jpg";
import VegasImg from "./Assets/Images/las vegas.jpg";

class App extends Component {
  render() {
    const Flex = {
      display: "flex",
      justifyContent: "space-around"
    };

    return (
      <div>
        <div>
          <Navbar />
        </div>
        <div style={Flex}>
          <Cards Img={NewyorkImg} Title="Newyork">I ❤ NY</Cards>
          <Cards Img={SingaporeImg} Title="Singapore">Singapore, We are comin'</Cards>
          <Cards Img={VegasImg} Title="Las Vegas">Lets Gamble fellas </Cards>
        </div>
      </div>
    );
  }
}
export default App;
