import "./App.scss";
import Cards from "./Components/Card/Cards";
import Navbar from "./Components/Navbar/Navbar";
import React, { Component } from "react";

class App extends Component {
  render() {
    const Flex = {
      display: "flex",
      justifyContent: "space-around"
    };

    return (
      <div>
        <div>
          <Navbar />
        </div>
        <div style={Flex}>
          <Cards />
          <Cards />
          <Cards />
        </div>
      </div>
    );
  }
}
export default App;
